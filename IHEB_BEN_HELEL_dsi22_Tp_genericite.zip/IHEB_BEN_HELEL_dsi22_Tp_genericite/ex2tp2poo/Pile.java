package ex2tp2poo;

interface Pile <P>{
	public boolean estVide();
	public P dernier();
	public void depiler();
	public void empiler(P o);
}