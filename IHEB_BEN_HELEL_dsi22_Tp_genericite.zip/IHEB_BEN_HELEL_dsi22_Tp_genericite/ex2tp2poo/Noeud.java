package ex2tp2poo;

public class Noeud <P>{
	P info;
	Noeud<P> suivant;
}